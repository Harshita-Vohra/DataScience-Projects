# This code is written in python
# The pandas library is used for data processing and to read data files
import pandas as pd 
#The matplotlib library is used to plot histograms and scatter plots
import matplotlib.pyplot as plt
# The GWCutilities has functions to help format data printed to the console
import GWCutilities as util

# Read a comma separated values (CSV) files into a variable
# as a pandas DataFrame
lwd=pd.read_csv("livwell135.csv")

print("Setting:")
print("This story takes place in rural areas of India and Senegal where educational access has been limited.\n")
input("Press enter to see the characters.\n")

print("Characters:")
print("- Diya: A 12 year old girl from India who wants to become a doctor but might have to drop out of school to help her mother.\n")
print("- Imani: A 14 year old girl from Senegal who wants to become a teacher but might have to drop out of school because of long commute travels.\n")
print("- Girls Who Code: A nonprofit organization who is advocating to help girls in both countries to get better access to educational resources and stay at school.\n")
input("Press enter to see the context. \n")

print("Context:")
print("Over the years, both countries have constantly been working to improve access to education, but challenges like poverty, cultural customs, and gender inequality still remain.\n")
print("They prevent children from staying in school for long periods of time to complete their education.\n")
print("In both India and Senegal, efforts have been made to fix this issue over the last two decades to improve educational access to girls.\n")
print("However, recent data that has been collected from Women's Well-being stated that the average years of education for women in India increased from about 5.4 years in 2000 to 8.2 years in 2020.\n")
print("In Senegal, the average grew from 2.8 years to 5.1 years in 2020.\n")
print("Despite their progress, many girls, especially those in rural areas, are still unable to finish primary education.\n")
input("So are research question remains... (press enter) \n")

print("Research question:")
print("What types of education policies are the most effective at increaseing the years of education in India and Senegal?\n")
input("Press enter to see the visualizations.\n")

# Print out the number of rows and columns
indiaData = lwd[lwd["country_name"] == "India"]
senegalData = lwd[lwd["country_name"] == "Senegal"]
plt.scatter(indiaData["year"], indiaData["ED_educ_years_mean"], color = "blue", label = "India")
plt.scatter(senegalData["year"], senegalData["ED_educ_years_mean"], color = "green", label = "Senegal")

plt.title("Average Years of Education: India vs Senegal")
plt.xlabel("Year")
plt.ylabel("Mean Years of Education")
plt.ylim(0,15)
plt.legend()
plt.show()

print("According to the scatter plot, there is a rise in the number of years a young girl can get their education year.\n")
print("In India, there is positive line that seems to be going upwards.\n")
print("Senegal, on the other hand, is taking its time but has been showing a positive line as well.\n")

print("Close the graph by pressing the 'X' in the top right corner.")
print("\nThank you for reading through my data analysis on womens education!")

